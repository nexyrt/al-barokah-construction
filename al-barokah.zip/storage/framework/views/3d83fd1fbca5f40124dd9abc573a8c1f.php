<?php if (isset($component)) { $__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.public','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.public'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    
    <section class="relative pt-32 pb-12 overflow-hidden">
        
        <div class="absolute inset-0 bg-gradient-to-br from-white via-primary-50/30 to-secondary-50/30">
            <div class="absolute inset-0 opacity-40">
                <div class="absolute top-0 right-1/4 w-64 h-64 bg-primary-200/40 rounded-full blur-3xl animate-pulse">
                </div>
                <div class="absolute bottom-0 left-1/4 w-80 h-80 bg-secondary-100/30 rounded-full blur-3xl animate-pulse"
                    style="animation-delay: 1s;"></div>
            </div>
        </div>

        
        <div class="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
            <div class="absolute top-20 left-10 w-16 h-16 border-2 border-primary-400 rotate-45 animate-fade-in"></div>
            <div class="absolute top-1/2 right-20 w-12 h-12 border-2 border-secondary-700 rounded-full animate-fade-in"
                style="animation-delay: 0.7s;"></div>
        </div>

        <div class="container-custom relative z-10">
            <div class="max-w-4xl mx-auto space-y-6">
                
                <div class="flex items-center gap-3 animate-fade-in">
                    <a href="<?php echo e(route('projects.index')); ?>"
                        class="group inline-flex items-center gap-2 px-4 py-2 border-2 border-neutral-300 hover:border-primary-600 hover:bg-primary-600 hover:text-white rounded-lg transition-all duration-300">
                        <svg class="h-4 w-4 group-hover:-translate-x-1 transition-all duration-300" fill="none"
                            stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7">
                            </path>
                        </svg>
                        <span>Portofolio</span>
                    </a>
                    <span class="text-neutral-400">/</span>
                    <span class="inline-flex items-center px-3 py-1 bg-neutral-100 text-neutral-700 text-sm rounded-lg">
                        <?php echo e($project->businessField->name); ?>

                    </span>
                </div>

                
                <div class="space-y-4 animate-fade-in" style="animation-delay: 0.1s;">
                    <div class="flex flex-wrap items-center gap-3">
                        
                        <span
                            class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium text-white
                            <?php echo e($project->status === 'completed' ? 'bg-success-600' : ($project->status === 'ongoing' ? 'bg-info-600' : 'bg-warning-600')); ?>">
                            <?php echo e($project->status === 'completed' ? 'Selesai' : ($project->status === 'ongoing' ? 'Berlangsung' : 'Perencanaan')); ?>

                        </span>

                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->is_featured): ?>
                            <span
                                class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border-2 border-primary-600 text-primary-600">
                                <span
                                    class="inline-block w-2 h-2 bg-primary-600 rounded-full mr-1.5 animate-pulse"></span>
                                Proyek Unggulan
                            </span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <h1 class="text-4xl md:text-6xl font-heading leading-tight text-secondary-900">
                        <?php echo e($project->title); ?>

                    </h1>
                </div>

                
                <div class="flex flex-wrap gap-6 text-sm text-neutral-600 animate-fade-in"
                    style="animation-delay: 0.2s;">
                    
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center">
                            <svg class="h-4 w-4 text-primary-600" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                            </svg>
                        </div>
                        <div>
                            <div class="text-xs text-neutral-500">Klien</div>
                            <div class="font-semibold text-secondary-900"><?php echo e($project->client_name); ?></div>
                        </div>
                    </div>

                    
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center">
                            <svg class="h-4 w-4 text-primary-600" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z">
                                </path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                            </svg>
                        </div>
                        <div>
                            <div class="text-xs text-neutral-500">Lokasi</div>
                            <div class="font-semibold text-secondary-900"><?php echo e($project->location); ?></div>
                        </div>
                    </div>

                    
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center">
                            <svg class="h-4 w-4 text-primary-600" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z">
                                </path>
                            </svg>
                        </div>
                        <div>
                            <div class="text-xs text-neutral-500">Dilihat</div>
                            <div class="font-semibold text-secondary-900"><?php echo e(number_format($project->views_count)); ?>

                                kali</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="py-12 bg-white">
        <div class="container-custom">
            <div class="max-w-6xl mx-auto space-y-8">

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->galleries && $project->galleries->count() > 0): ?>
                    <div x-data="projectGallery(<?php echo e($project->galleries->count()); ?>)" class="relative">
                        
                        <div class="relative aspect-video rounded-2xl overflow-hidden bg-neutral-200 shadow-2xl">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $project->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div x-show="currentSlide === <?php echo e($index); ?>"
                                    x-transition:enter="transition-opacity duration-500"
                                    x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
                                    x-transition:leave="transition-opacity duration-500"
                                    x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
                                    class="absolute inset-0" style="<?php echo e($index !== 0 ? 'display: none;' : ''); ?>">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filter_var($gallery->image_path, FILTER_VALIDATE_URL)): ?>
                                        <img src="<?php echo e($gallery->image_path); ?>"
                                            alt="<?php echo e($gallery->caption ?? $project->title); ?>"
                                            class="w-full h-full object-cover">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('storage/' . $gallery->image_path)); ?>"
                                            alt="<?php echo e($gallery->caption ?? $project->title); ?>"
                                            class="w-full h-full object-cover">
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                    
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($gallery->caption): ?>
                                        <div
                                            class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-secondary-900/90 via-secondary-900/60 to-transparent p-6">
                                            <p class="text-white text-sm md:text-base font-medium">
                                                <?php echo e($gallery->caption); ?></p>
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            
                            <button @click="prevSlide()"
                                class="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all duration-300 group"
                                aria-label="Previous image">
                                <svg class="w-6 h-6 text-secondary-900 group-hover:-translate-x-1 transition-transform"
                                    fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M15 19l-7-7 7-7"></path>
                                </svg>
                            </button>
                            <button @click="nextSlide()"
                                class="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-lg transition-all duration-300 group"
                                aria-label="Next image">
                                <svg class="w-6 h-6 text-secondary-900 group-hover:translate-x-1 transition-transform"
                                    fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 5l7 7-7 7"></path>
                                </svg>
                            </button>

                            
                            <div
                                class="absolute top-4 right-4 bg-secondary-900/80 backdrop-blur-sm text-white px-4 py-2 rounded-lg text-sm font-medium">
                                <span x-text="currentSlide + 1"></span> / <span x-text="totalSlides"></span>
                            </div>
                        </div>

                        
                        <div class="mt-4 grid grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $project->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button @click="goToSlide(<?php echo e($index); ?>)"
                                    :class="currentSlide === <?php echo e($index); ?> ? 'ring-2 ring-primary-600 ring-offset-2' :
                                        'ring-1 ring-neutral-300 hover:ring-primary-400'"
                                    class="aspect-video rounded-lg overflow-hidden transition-all duration-300 focus:outline-none">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filter_var($gallery->image_path, FILTER_VALIDATE_URL)): ?>
                                        <img src="<?php echo e($gallery->image_path); ?>" alt="Thumbnail <?php echo e($index + 1); ?>"
                                            class="w-full h-full object-cover">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('storage/' . $gallery->image_path)); ?>"
                                            alt="Thumbnail <?php echo e($index + 1); ?>" class="w-full h-full object-cover">
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                <?php else: ?>
                    
                    <div class="relative aspect-video rounded-2xl overflow-hidden bg-neutral-200 shadow-xl group">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->thumbnail && filter_var($project->thumbnail, FILTER_VALIDATE_URL)): ?>
                            <img src="<?php echo e($project->thumbnail); ?>" alt="<?php echo e($project->title); ?>"
                                class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105">
                        <?php elseif($project->thumbnail): ?>
                            <img src="<?php echo e(asset('storage/' . $project->thumbnail)); ?>" alt="<?php echo e($project->title); ?>"
                                class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105">
                        <?php else: ?>
                            <div
                                class="w-full h-full bg-gradient-to-br from-primary-400 via-primary-600 to-secondary-700 flex items-center justify-center">
                                <span
                                    class="text-white text-9xl font-heading opacity-20"><?php echo e(substr($project->title, 0, 1)); ?></span>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        <div
                            class="absolute inset-0 bg-gradient-to-t from-secondary-900/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->tags && $project->tags->count() > 0): ?>
                    <div class="flex flex-wrap gap-2">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $project->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span
                                class="inline-flex items-center px-3 py-1 bg-neutral-100 text-neutral-700 text-xs font-medium rounded-lg hover:bg-primary-100 hover:text-primary-700 transition-all duration-300">
                                <svg class="w-3 h-3 mr-1.5" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd"
                                        d="M17.707 9.293a1 1 0 010 1.414l-7 7a1 1 0 01-1.414 0l-7-7A.997.997 0 012 10V5a3 3 0 013-3h5c.256 0 .512.098.707.293l7 7zM5 6a1 1 0 100-2 1 1 0 000 2z"
                                        clip-rule="evenodd"></path>
                                </svg>
                                <?php echo e($tag->name); ?>

                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <div class="space-y-8">
                    
                    <div class="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-sm">
                        <div class="bg-gradient-to-r from-primary-600 to-primary-700 px-6 py-4">
                            <h2 class="text-xl font-heading font-bold text-white flex items-center gap-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z">
                                    </path>
                                </svg>
                                Informasi Proyek
                            </h2>
                        </div>

                        <div class="overflow-x-auto">
                            <table class="w-full">
                                <tbody class="divide-y divide-neutral-200">
                                    
                                    <tr class="hover:bg-neutral-50 transition-colors">
                                        <td class="px-6 py-4 w-1/3">
                                            <div class="flex items-center gap-3">
                                                <div class="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center flex-shrink-0">
                                                    <svg class="w-5 h-5 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z">
                                                        </path>
                                                    </svg>
                                                </div>
                                                <span class="font-semibold text-neutral-700">Periode</span>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div>
                                                <p class="font-bold text-secondary-900">
                                                    <?php echo e(\Carbon\Carbon::parse($project->start_date)->translatedFormat('F Y')); ?>

                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->end_date): ?>
                                                        - <?php echo e(\Carbon\Carbon::parse($project->end_date)->translatedFormat('F Y')); ?>

                                                    <?php else: ?>
                                                        <span class="text-info-600 font-semibold ml-2">(Sedang Berjalan)</span>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </p>
                                            </div>
                                        </td>
                                    </tr>

                                    
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->duration_months): ?>
                                        <tr class="hover:bg-neutral-50 transition-colors">
                                            <td class="px-6 py-4">
                                                <div class="flex items-center gap-3">
                                                    <div class="w-10 h-10 bg-info-100 rounded-lg flex items-center justify-center flex-shrink-0">
                                                        <svg class="w-5 h-5 text-info-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                                d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                                        </svg>
                                                    </div>
                                                    <span class="font-semibold text-neutral-700">Durasi</span>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4">
                                                <p class="font-bold text-secondary-900"><?php echo e($project->duration_months); ?> Bulan</p>
                                            </td>
                                        </tr>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                    
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->project_value): ?>
                                        <tr class="hover:bg-neutral-50 transition-colors">
                                            <td class="px-6 py-4">
                                                <div class="flex items-center gap-3">
                                                    <div class="w-10 h-10 bg-success-100 rounded-lg flex items-center justify-center flex-shrink-0">
                                                        <svg class="w-5 h-5 text-success-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                                d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z">
                                                            </path>
                                                        </svg>
                                                    </div>
                                                    <span class="font-semibold text-neutral-700">Nilai Proyek</span>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4">
                                                <p class="font-bold text-secondary-900 text-lg">Rp <?php echo e(number_format($project->project_value, 0, ',', '.')); ?></p>
                                            </td>
                                        </tr>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                    
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->area_size): ?>
                                        <tr class="hover:bg-neutral-50 transition-colors">
                                            <td class="px-6 py-4">
                                                <div class="flex items-center gap-3">
                                                    <div class="w-10 h-10 bg-warning-100 rounded-lg flex items-center justify-center flex-shrink-0">
                                                        <svg class="w-5 h-5 text-warning-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                                d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4">
                                                            </path>
                                                        </svg>
                                                    </div>
                                                    <span class="font-semibold text-neutral-700">Luas Area</span>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4">
                                                <p class="font-bold text-secondary-900 text-lg"><?php echo e($project->area_size); ?></p>
                                            </td>
                                        </tr>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    
                    <div class="bg-white border border-neutral-200 rounded-xl overflow-hidden shadow-sm">
                        <div class="bg-gradient-to-r from-primary-600 to-primary-700 px-6 py-4">
                            <h2 class="text-xl font-heading font-bold text-white flex items-center gap-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z">
                                    </path>
                                </svg>
                                Deskripsi Proyek
                            </h2>
                        </div>
                        <div class="px-6 py-6">
                            <div class="prose prose-neutral max-w-none">
                                <p class="text-neutral-700 leading-relaxed whitespace-pre-line">
                                    <?php echo e($project->description); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->testimonials && $project->testimonials->count() > 0): ?>
                    <div class="space-y-6 pt-4">
                        <h2 class="text-2xl font-heading font-bold text-secondary-900 flex items-center gap-2">
                            <svg class="w-6 h-6 text-warning-600" fill="currentColor" viewBox="0 0 20 20">
                                <path
                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                </path>
                            </svg>
                            Testimoni Klien
                        </h2>

                        <div class="grid md:grid-cols-2 gap-6">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $project->testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div
                                    class="bg-neutral-50 border border-neutral-200 rounded-xl p-6 hover:border-primary-600 hover:shadow-md transition-all duration-300">
                                    
                                    <div class="flex items-center gap-1 mb-4">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i = 1; $i <= 5; $i++): ?>
                                            <svg class="w-5 h-5 <?php echo e($i <= $testimonial->rating ? 'text-warning-500 fill-warning-500' : 'text-neutral-300 fill-neutral-300'); ?>"
                                                viewBox="0 0 20 20">
                                                <path
                                                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z">
                                                </path>
                                            </svg>
                                        <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>

                                    
                                    <p class="text-neutral-700 italic mb-4 leading-relaxed">
                                        "<?php echo e($testimonial->testimonial); ?>"
                                    </p>

                                    
                                    <div class="flex items-center gap-3 pt-4 border-t border-neutral-200">
                                        <div
                                            class="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0">
                                            <span
                                                class="text-primary-600 font-bold text-lg"><?php echo e(substr($testimonial->client_name, 0, 1)); ?></span>
                                        </div>
                                        <div>
                                            <p class="font-semibold text-secondary-900">
                                                <?php echo e($testimonial->client_name); ?></p>
                                            <p class="text-sm text-neutral-600"><?php echo e($testimonial->position); ?></p>
                                            <p class="text-sm text-primary-600 font-medium">
                                                <?php echo e($testimonial->company); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($relatedProjects->count() > 0): ?>
                    <div class="space-y-6 pt-4">
                        <div class="flex items-center justify-between">
                            <h2 class="text-2xl font-heading font-bold text-secondary-900">Proyek Terkait</h2>
                            <a href="<?php echo e(route('projects.index')); ?>"
                                class="text-primary-600 hover:text-primary-700 font-medium text-sm flex items-center gap-1 group">
                                <span>Lihat Semua</span>
                                <svg class="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none"
                                    stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 5l7 7-7 7"></path>
                                </svg>
                            </a>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $relatedProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relProject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('projects.show', $relProject->slug)); ?>"
                                    class="card group overflow-hidden hover:shadow-xl transition-all duration-300">
                                    
                                    <div class="aspect-video relative overflow-hidden bg-neutral-200">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($relProject->thumbnail && filter_var($relProject->thumbnail, FILTER_VALIDATE_URL)): ?>
                                            <img src="<?php echo e($relProject->thumbnail); ?>" alt="<?php echo e($relProject->title); ?>"
                                                class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                                        <?php elseif($relProject->thumbnail): ?>
                                            <img src="<?php echo e(asset('storage/' . $relProject->thumbnail)); ?>"
                                                alt="<?php echo e($relProject->title); ?>"
                                                class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                                        <?php else: ?>
                                            <div
                                                class="w-full h-full bg-gradient-to-br from-primary-400 to-secondary-700 flex items-center justify-center">
                                                <span
                                                    class="text-white text-6xl font-heading opacity-20"><?php echo e(substr($relProject->title, 0, 1)); ?></span>
                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        
                                        <div class="absolute top-3 right-3">
                                            <span
                                                class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold text-white backdrop-blur-sm
                                        <?php echo e($relProject->status === 'completed' ? 'bg-success-600/90' : ($relProject->status === 'ongoing' ? 'bg-info-600/90' : 'bg-warning-600/90')); ?>">
                                                <?php echo e($relProject->status === 'completed' ? 'Selesai' : ($relProject->status === 'ongoing' ? 'Berlangsung' : 'Perencanaan')); ?>

                                            </span>
                                        </div>
                                    </div>

                                    
                                    <div class="p-5">
                                        <span
                                            class="text-xs font-semibold text-primary-600 uppercase tracking-wide"><?php echo e($relProject->businessField->name); ?></span>
                                        <h3
                                            class="text-lg font-heading font-bold text-secondary-900 mt-2 mb-3 line-clamp-2 group-hover:text-primary-600 transition-colors">
                                            <?php echo e($relProject->title); ?>

                                        </h3>
                                        <div class="flex items-center gap-2 text-sm text-neutral-600">
                                            <svg class="h-4 w-4" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z">
                                                </path>
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                            </svg>
                                            <span class="truncate"><?php echo e($relProject->location); ?></span>
                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <div
                    class="bg-gradient-to-br from-secondary-900 to-secondary-800 text-white rounded-2xl p-8 md:p-10 text-center space-y-4">
                    <h3 class="text-2xl md:text-3xl font-heading font-bold">Tertarik dengan Proyek Serupa?</h3>
                    <p class="text-white/90 max-w-2xl mx-auto">
                        Konsultasikan kebutuhan konstruksi Anda dengan tim ahli kami
                    </p>
                    <a href="<?php echo e(route('home')); ?>#contact"
                        class="inline-flex items-center bg-primary-600 hover:bg-primary-700 text-white font-semibold px-8 py-4 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl">
                        <span>Hubungi Kami</span>
                        <svg class="ml-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </section>

    
    <?php $__env->startPush('scripts'); ?>
        <script>
            function projectGallery(total) {
                return {
                    currentSlide: 0,
                    totalSlides: total,

                    init() {
                        // Auto-rotate setiap 5 detik
                        setInterval(() => {
                            this.nextSlide();
                        }, 5000);

                        // Keyboard navigation
                        document.addEventListener('keydown', (e) => {
                            if (e.key === 'ArrowLeft') this.prevSlide();
                            if (e.key === 'ArrowRight') this.nextSlide();
                        });
                    },

                    nextSlide() {
                        this.currentSlide = (this.currentSlide + 1) % this.totalSlides;
                    },

                    prevSlide() {
                        this.currentSlide = (this.currentSlide - 1 + this.totalSlides) % this.totalSlides;
                    },

                    goToSlide(index) {
                        this.currentSlide = index;
                    }
                }
            }
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd)): ?>
<?php $attributes = $__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd; ?>
<?php unset($__attributesOriginal8c0e86a062c1c5bb6d0e151b7076f3fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd)): ?>
<?php $component = $__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd; ?>
<?php unset($__componentOriginal8c0e86a062c1c5bb6d0e151b7076f3fd); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Lenovo\Documents\Application\al-barokah\resources\views/projects/show.blade.php ENDPATH**/ ?>