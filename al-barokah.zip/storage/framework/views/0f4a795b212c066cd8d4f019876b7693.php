<div>
    <?php if (isset($component)) { $__componentOriginal1e4ad31a2d48f80c4d166169a7bc0d88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1e4ad31a2d48f80c4d166169a7bc0d88 = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Button\Circle::resolve(['icon' => 'trash','color' => 'red','size' => 'sm'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button.circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Button\Circle::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'confirm','title' => 'Delete']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1e4ad31a2d48f80c4d166169a7bc0d88)): ?>
<?php $attributes = $__attributesOriginal1e4ad31a2d48f80c4d166169a7bc0d88; ?>
<?php unset($__attributesOriginal1e4ad31a2d48f80c4d166169a7bc0d88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1e4ad31a2d48f80c4d166169a7bc0d88)): ?>
<?php $component = $__componentOriginal1e4ad31a2d48f80c4d166169a7bc0d88; ?>
<?php unset($__componentOriginal1e4ad31a2d48f80c4d166169a7bc0d88); ?>
<?php endif; ?>
</div><?php /**PATH C:\Users\Lenovo\Documents\Application\al-barokah\storage\framework\views/32f8d9fae452221019b08eddf718c285.blade.php ENDPATH**/ ?>