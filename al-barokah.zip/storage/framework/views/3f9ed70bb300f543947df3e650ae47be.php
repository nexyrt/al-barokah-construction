<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['class']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['class']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php if (isset($component)) { $__componentOriginale9e17eb7bc8ed6f93291b1e15b6d9ae7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9e17eb7bc8ed6f93291b1e15b6d9ae7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'tallstack-ui::components.icon.heroicons.solid.building-office','data' => ['class' => $class]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tallstack-ui::icon.heroicons.solid.building-office'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9e17eb7bc8ed6f93291b1e15b6d9ae7)): ?>
<?php $attributes = $__attributesOriginale9e17eb7bc8ed6f93291b1e15b6d9ae7; ?>
<?php unset($__attributesOriginale9e17eb7bc8ed6f93291b1e15b6d9ae7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9e17eb7bc8ed6f93291b1e15b6d9ae7)): ?>
<?php $component = $__componentOriginale9e17eb7bc8ed6f93291b1e15b6d9ae7; ?>
<?php unset($__componentOriginale9e17eb7bc8ed6f93291b1e15b6d9ae7); ?>
<?php endif; ?><?php /**PATH C:\Users\Lenovo\Documents\Application\al-barokah\storage\framework\views/2238e23beee5c564e58e56bcf96a1d1b.blade.php ENDPATH**/ ?>