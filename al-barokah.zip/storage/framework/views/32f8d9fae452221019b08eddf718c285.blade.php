<div>
    <x-button.circle icon="trash" color="red" size="sm" wire:click="confirm" title="Delete" />
</div>