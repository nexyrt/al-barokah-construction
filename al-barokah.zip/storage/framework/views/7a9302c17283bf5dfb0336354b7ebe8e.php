<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['class']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['class']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php if (isset($component)) { $__componentOriginal1dbdec19e4726d0ae00b4c32df95ac1c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1dbdec19e4726d0ae00b4c32df95ac1c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'tallstack-ui::components.icon.heroicons.solid.shopping-cart','data' => ['class' => $class]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tallstack-ui::icon.heroicons.solid.shopping-cart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1dbdec19e4726d0ae00b4c32df95ac1c)): ?>
<?php $attributes = $__attributesOriginal1dbdec19e4726d0ae00b4c32df95ac1c; ?>
<?php unset($__attributesOriginal1dbdec19e4726d0ae00b4c32df95ac1c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1dbdec19e4726d0ae00b4c32df95ac1c)): ?>
<?php $component = $__componentOriginal1dbdec19e4726d0ae00b4c32df95ac1c; ?>
<?php unset($__componentOriginal1dbdec19e4726d0ae00b4c32df95ac1c); ?>
<?php endif; ?><?php /**PATH C:\Users\Lenovo\Documents\Application\al-barokah\storage\framework\views/29aac2d29364fc42757aaa7dede4244d.blade.php ENDPATH**/ ?>