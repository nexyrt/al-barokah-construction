<div class="space-y-6">
    
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div class="space-y-1">
            <h1 class="text-4xl font-bold text-zinc-900 dark:text-zinc-50">
                Projects
            </h1>
            <p class="text-zinc-600 dark:text-zinc-400">
                Manage your construction projects
            </p>
        </div>

        <?php if (isset($component)) { $__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5 = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Button\Button::resolve(['href' => route('admin.projects.create'),'color' => 'primary','icon' => 'plus'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Button\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:navigate' => true]); ?>
            Add Project
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5)): ?>
<?php $attributes = $__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5; ?>
<?php unset($__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5)): ?>
<?php $component = $__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5; ?>
<?php unset($__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5); ?>
<?php endif; ?>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        <?php if (isset($component)) { $__componentOriginala430b17f53e054e8e8f4eba8f1e2ea14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala430b17f53e054e8e8f4eba8f1e2ea14 = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Form\Select\Styled::resolve(['label' => 'Status','options' => $this->statuses,'placeholder' => 'All Status','select' => 'label:label|value:value'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select.styled'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Form\Select\Styled::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.live' => 'status']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala430b17f53e054e8e8f4eba8f1e2ea14)): ?>
<?php $attributes = $__attributesOriginala430b17f53e054e8e8f4eba8f1e2ea14; ?>
<?php unset($__attributesOriginala430b17f53e054e8e8f4eba8f1e2ea14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala430b17f53e054e8e8f4eba8f1e2ea14)): ?>
<?php $component = $__componentOriginala430b17f53e054e8e8f4eba8f1e2ea14; ?>
<?php unset($__componentOriginala430b17f53e054e8e8f4eba8f1e2ea14); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginala430b17f53e054e8e8f4eba8f1e2ea14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala430b17f53e054e8e8f4eba8f1e2ea14 = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Form\Select\Styled::resolve(['label' => 'Business Field','options' => $this->businessFields,'placeholder' => 'All Business Fields','select' => 'label:label|value:value','searchable' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select.styled'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Form\Select\Styled::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.live' => 'businessField']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala430b17f53e054e8e8f4eba8f1e2ea14)): ?>
<?php $attributes = $__attributesOriginala430b17f53e054e8e8f4eba8f1e2ea14; ?>
<?php unset($__attributesOriginala430b17f53e054e8e8f4eba8f1e2ea14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala430b17f53e054e8e8f4eba8f1e2ea14)): ?>
<?php $component = $__componentOriginala430b17f53e054e8e8f4eba8f1e2ea14; ?>
<?php unset($__componentOriginala430b17f53e054e8e8f4eba8f1e2ea14); ?>
<?php endif; ?>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($status || $businessField): ?>
            <div class="flex items-center">
                <?php if (isset($component)) { $__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5 = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Button\Button::resolve(['color' => 'secondary','outline' => true,'icon' => 'x-mark'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Button\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'clearFilters','class' => 'w-full']); ?>
                    Clear Filters
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5)): ?>
<?php $attributes = $__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5; ?>
<?php unset($__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5)): ?>
<?php $component = $__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5; ?>
<?php unset($__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5); ?>
<?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    
    <?php if (isset($component)) { $__componentOriginale203a0d956de03ad9636925fe99d9647 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale203a0d956de03ad9636925fe99d9647 = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Table::resolve(['headers' => $headers,'sort' => $sort,'rows' => $this->rows(),'selectable' => true,'paginate' => true,'quantity' => [10, 25, 50, 100],'filter' => true,'loading' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Table::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.live' => 'selected','id' => 'projects-table']); ?>

        
        <?php $loop = null; $__env->slot('column_title', function($row) use ($__env) { $loop = (object) $__env->getLoopStack()[0] ?>
            <div class="flex items-center gap-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($row->thumbnail): ?>
                    <img src="<?php echo e(asset('storage/' . $row->thumbnail)); ?>" alt="<?php echo e($row->title); ?>"
                        class="h-10 w-10 rounded object-cover">
                <?php else: ?>
                    <div class="flex h-10 w-10 items-center justify-center rounded bg-zinc-200 dark:bg-zinc-700">
                        <?php if (isset($component)) { $__componentOriginalcf0c10903472319464d99a08725e554d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcf0c10903472319464d99a08725e554d = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Icon::resolve(['name' => 'photo'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Icon::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 w-5 text-zinc-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcf0c10903472319464d99a08725e554d)): ?>
<?php $attributes = $__attributesOriginalcf0c10903472319464d99a08725e554d; ?>
<?php unset($__attributesOriginalcf0c10903472319464d99a08725e554d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcf0c10903472319464d99a08725e554d)): ?>
<?php $component = $__componentOriginalcf0c10903472319464d99a08725e554d; ?>
<?php unset($__componentOriginalcf0c10903472319464d99a08725e554d); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div>
                    <div class="font-medium text-zinc-900 dark:text-zinc-100">
                        <?php echo e(Str::limit($row->title, 40)); ?>

                    </div>
                    <div class="text-xs text-zinc-500">
                        #<?php echo e($row->id); ?>

                    </div>
                </div>
            </div>
        <?php }); ?>

        
        <?php $loop = null; $__env->slot('column_client_name', function($row) use ($__env) { $loop = (object) $__env->getLoopStack()[0] ?>
            <span class="text-sm text-zinc-900 dark:text-zinc-100"><?php echo e($row->client_name); ?></span>
        <?php }); ?>

        
        <?php $loop = null; $__env->slot('column_business_field', function($row) use ($__env) { $loop = (object) $__env->getLoopStack()[0] ?>
            <?php if (isset($component)) { $__componentOriginald4f7a28b506528bea1d997c58f333646 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald4f7a28b506528bea1d997c58f333646 = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Badge::resolve(['color' => 'zinc','text' => ''.e($row->businessField->name).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Badge::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald4f7a28b506528bea1d997c58f333646)): ?>
<?php $attributes = $__attributesOriginald4f7a28b506528bea1d997c58f333646; ?>
<?php unset($__attributesOriginald4f7a28b506528bea1d997c58f333646); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4f7a28b506528bea1d997c58f333646)): ?>
<?php $component = $__componentOriginald4f7a28b506528bea1d997c58f333646; ?>
<?php unset($__componentOriginald4f7a28b506528bea1d997c58f333646); ?>
<?php endif; ?>
        <?php }); ?>

        
        <?php $loop = null; $__env->slot('column_location', function($row) use ($__env) { $loop = (object) $__env->getLoopStack()[0] ?>
            <span class="text-sm text-zinc-700 dark:text-zinc-300"><?php echo e(Str::limit($row->location ?? '-', 30)); ?></span>
        <?php }); ?>

        
        <?php $loop = null; $__env->slot('column_status', function($row) use ($__env) { $loop = (object) $__env->getLoopStack()[0] ?>
            <?php if (isset($component)) { $__componentOriginald4f7a28b506528bea1d997c58f333646 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald4f7a28b506528bea1d997c58f333646 = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Badge::resolve(['text' => ucfirst(str_replace('_', ' ', $row->status)),'color' => match ($row->status) {
                'completed' => 'green',
                'ongoing' => 'blue',
                'planning' => 'yellow',
                'on_hold' => 'red',
                default => 'zinc',
            }] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Badge::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald4f7a28b506528bea1d997c58f333646)): ?>
<?php $attributes = $__attributesOriginald4f7a28b506528bea1d997c58f333646; ?>
<?php unset($__attributesOriginald4f7a28b506528bea1d997c58f333646); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4f7a28b506528bea1d997c58f333646)): ?>
<?php $component = $__componentOriginald4f7a28b506528bea1d997c58f333646; ?>
<?php unset($__componentOriginald4f7a28b506528bea1d997c58f333646); ?>
<?php endif; ?>
        <?php }); ?>

        
        <?php $loop = null; $__env->slot('column_dates', function($row) use ($__env) { $loop = (object) $__env->getLoopStack()[0] ?>
            <div class="text-xs text-zinc-600 dark:text-zinc-400">
                <div>Start: <?php echo e($row->start_date->format('M d, Y')); ?></div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($row->end_date): ?>
                    <div>End: <?php echo e($row->end_date->format('M d, Y')); ?></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php }); ?>

        
        <?php $loop = null; $__env->slot('column_is_featured', function($row) use ($__env) { $loop = (object) $__env->getLoopStack()[0] ?>
            <button type="button" wire:click="toggleFeatured(<?php echo e($row->id); ?>)" x-data="{ enabled: <?php echo e($row->is_featured ? 'true' : 'false'); ?> }"
                x-init="$watch('$wire.rows', () => enabled = <?php echo e($row->is_featured ? 'true' : 'false'); ?>)" @click="enabled = !enabled"
                :class="enabled ? 'bg-blue-600' : 'bg-zinc-200 dark:bg-zinc-700'"
                class="relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-zinc-900">
                <span :class="enabled ? 'translate-x-5' : 'translate-x-1'"
                    class="inline-block h-3 w-3 transform rounded-full bg-white transition-transform">
                </span>
            </button>
        <?php }); ?>

        
        <?php $loop = null; $__env->slot('column_is_published', function($row) use ($__env) { $loop = (object) $__env->getLoopStack()[0] ?>
            <button type="button" wire:click="togglePublished(<?php echo e($row->id); ?>)" x-data="{ enabled: <?php echo e($row->is_published ? 'true' : 'false'); ?> }"
                x-init="$watch('$wire.rows', () => enabled = <?php echo e($row->is_published ? 'true' : 'false'); ?>)" @click="enabled = !enabled"
                :class="enabled ? 'bg-green-600' : 'bg-zinc-200 dark:bg-zinc-700'"
                class="relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 dark:focus:ring-offset-zinc-900">
                <span :class="enabled ? 'translate-x-5' : 'translate-x-1'"
                    class="inline-block h-3 w-3 transform rounded-full bg-white transition-transform">
                </span>
            </button>
        <?php }); ?>

        
        <?php $loop = null; $__env->slot('column_action', function($row) use ($__env) { $loop = (object) $__env->getLoopStack()[0] ?>
            <div class="flex items-center gap-1">
                <?php if (isset($component)) { $__componentOriginal1e4ad31a2d48f80c4d166169a7bc0d88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1e4ad31a2d48f80c4d166169a7bc0d88 = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Button\Circle::resolve(['href' => route('admin.projects.edit', $row),'icon' => 'pencil','color' => 'blue','size' => 'sm'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button.circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Button\Circle::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:navigate' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1e4ad31a2d48f80c4d166169a7bc0d88)): ?>
<?php $attributes = $__attributesOriginal1e4ad31a2d48f80c4d166169a7bc0d88; ?>
<?php unset($__attributesOriginal1e4ad31a2d48f80c4d166169a7bc0d88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1e4ad31a2d48f80c4d166169a7bc0d88)): ?>
<?php $component = $__componentOriginal1e4ad31a2d48f80c4d166169a7bc0d88; ?>
<?php unset($__componentOriginal1e4ad31a2d48f80c4d166169a7bc0d88); ?>
<?php endif; ?>

                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.projects.delete', ['project' => $row]);

$key = 'delete-' . $row->id;

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-787317141-0', 'delete-' . $row->id);

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        <?php }); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale203a0d956de03ad9636925fe99d9647)): ?>
<?php $attributes = $__attributesOriginale203a0d956de03ad9636925fe99d9647; ?>
<?php unset($__attributesOriginale203a0d956de03ad9636925fe99d9647); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale203a0d956de03ad9636925fe99d9647)): ?>
<?php $component = $__componentOriginale203a0d956de03ad9636925fe99d9647; ?>
<?php unset($__componentOriginale203a0d956de03ad9636925fe99d9647); ?>
<?php endif; ?>

    
    <div x-data="{ show: <?php if ((object) ('selected') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('selected'->value()); ?>')<?php echo e('selected'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('selected'); ?>')<?php endif; ?>.live }" x-show="show.length > 0" x-transition
        class="fixed bottom-4 sm:bottom-6 left-4 right-4 sm:left-1/2 sm:right-auto sm:transform sm:-translate-x-1/2 z-50">
        <div
            class="bg-white dark:bg-zinc-800 rounded-xl shadow-lg border border-zinc-200 dark:border-zinc-600 px-4 sm:px-6 py-4 sm:min-w-96">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 sm:gap-6">
                <div class="flex items-center gap-3">
                    <div
                        class="h-10 w-10 bg-primary-50 dark:bg-primary-900/20 rounded-xl flex items-center justify-center">
                        <?php if (isset($component)) { $__componentOriginalcf0c10903472319464d99a08725e554d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcf0c10903472319464d99a08725e554d = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Icon::resolve(['name' => 'check-circle'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Icon::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-primary-600 dark:text-primary-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcf0c10903472319464d99a08725e554d)): ?>
<?php $attributes = $__attributesOriginalcf0c10903472319464d99a08725e554d; ?>
<?php unset($__attributesOriginalcf0c10903472319464d99a08725e554d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcf0c10903472319464d99a08725e554d)): ?>
<?php $component = $__componentOriginalcf0c10903472319464d99a08725e554d; ?>
<?php unset($__componentOriginalcf0c10903472319464d99a08725e554d); ?>
<?php endif; ?>
                    </div>
                    <div>
                        <div class="font-semibold text-zinc-900 dark:text-zinc-50"
                            x-text="`${show.length} projects selected`"></div>
                        <div class="text-xs text-zinc-500 dark:text-zinc-400">Choose action for selected projects</div>
                    </div>
                </div>
                <div class="flex items-center gap-2 justify-end">
                    <?php if (isset($component)) { $__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5 = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Button\Button::resolve(['size' => 'sm','color' => 'red','icon' => 'trash'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Button\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'confirmBulkDelete']); ?>
                        Delete
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5)): ?>
<?php $attributes = $__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5; ?>
<?php unset($__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5)): ?>
<?php $component = $__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5; ?>
<?php unset($__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5 = $attributes; } ?>
<?php $component = TallStackUi\View\Components\Button\Button::resolve(['size' => 'sm','color' => 'secondary','icon' => 'x-mark'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\TallStackUi\View\Components\Button\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => '$set(\'selected\', [])']); ?>
                        Cancel
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5)): ?>
<?php $attributes = $__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5; ?>
<?php unset($__attributesOriginal5266464ff7b66ba0b126f4b6bc32a5f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5)): ?>
<?php $component = $__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5; ?>
<?php unset($__componentOriginal5266464ff7b66ba0b126f4b6bc32a5f5); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Lenovo\Documents\Application\al-barokah\resources\views/livewire/admin/projects/index.blade.php ENDPATH**/ ?>